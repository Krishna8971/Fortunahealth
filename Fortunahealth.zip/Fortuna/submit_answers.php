        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Get form data
            $name = $_POST["name"];
            $answers = [
                $_POST["answer-1"],
                $_POST["answer-2"],
                $_POST["answer-3"],
                $_POST["answer-4"],
                $_POST["answer-5"]
            ];

            // Send answers to Discord channel
            $webhook_url = "https://discord.com/api/webhooks/1276458094968438826/_bodmvrB0jqQDLdtQZnK5_fSOqSrbQlZ4maYRwkb-P-KnEzyVWuQhXyfIe74leq4832j"; // Replace with your own webhook URL
            $data = [
                "username" => "FortunaHealth Reports",
                "content" => "**Report of Patient: " . $name . "**\n\n" .
                    "1. " . $answers[0] . "\n" .
                    "2. " . $answers[1] . "\n" .
                    "3. " . $answers[2] . "\n" .
                    "4. " . $answers[3] . "\n" .
                    "5. " . $answers[4]
            ];
            $options = [
                "http" => [
                    "header" => "Content-type: application/json\r\n",
                    "method" => "POST",
                    "content" => json_encode($data)
                ]
            ];
            $context = stream_context_create($options);
            $result = file_get_contents($webhook_url, false, $context);
        }
        ?>

        <!DOCTYPE html>
        <html lang="en-US">
        <head>
          <meta charset="utf-8">
          <title>Random Questions</title>
          <!-- Link to Fortuna Health CSS files -->
          <link rel="stylesheet" href="css/components.css">
          <link rel="stylesheet" href="css/icons.css">
          <link rel="stylesheet" href="css/responsee.css">
          <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
          <link rel="stylesheet" href="owl-carousel/owl.theme.css">
          <!-- Custom Style -->
          <link rel="stylesheet" href="css/template-style.css">
          <link href="https://fonts.googleapis.com/css?family=Barlow:100,300,400,700,800&amp;subset=latin-ext" rel="stylesheet">
          <style>
            body {
              background-color: beige;
              color: black;
              font-family: 'Barlow', sans-serif;
            }
            #quiz-form {
              max-width: 600px;
              margin: 0 auto;
              padding: 20px;
              background-color: #fff;
              border-radius: 8px;
              box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            #quiz-form label {
              display: block;
              margin-bottom: 8px;
              font-weight: bold;
            }
            #quiz-form input[type="text"] {
              width: 100%;
              padding: 10px;
              margin-bottom: 15px;
              border: 1px solid #ccc;
              border-radius: 4px;
            }
            #quiz-form button {
              background-color: #e74c3c;
              color: #fff;
              border: none;
              padding: 10px 20px;
              border-radius: 4px;
              cursor: pointer;
              font-size: 16px;
            }
            #quiz-form button:hover {
              background-color: #c0392b;
            }
            #success-message {
              background-color: white;
              color: black;
              padding: 10px;
              margin-top: 20px;
              text-align: center;
              border-radius: 4px;
              box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            }
          </style>
        </head>
        <body class="size-1520 primary-color-red background-dark">
          <!-- HEADER -->
          <header class="grid">
            <nav class="s-12 grid background-none background-primary-hightlight">
              <a href="index.html" class="m-12 l-3 padding-2x logo">
                <img src="img/Fortuna.svg" width="100" height="100">
              </a>
              <div class="top-nav s-12 l-9">
                <ul class="top-ul right chevron">
                  <li><a href="index.html">Home</a></li>
                  <li><a href="about-us.html">About Us</a></li>
                  <li><a href="contact.html">Contact</a></li>
                </ul>
              </div>
            </nav>
          </header>

          <!-- MAIN -->
          <main role="main">
            <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
              <!-- Success Message -->
          <div id="success-message" style="
            position: fixed; /* Fixes the div to the viewport */
            top: 50%; /* Centers the div vertically */
            left: 50%; /* Centers the div horizontally */
            transform: translate(-50%, -50%); /* Adjusts for perfect centering */
            background-color: #fff; /* White background */
            padding: 20px; /* Adds internal space */
            border-radius: 8px; /* Rounds the corners */
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2); /* Subtle shadow effect */
            text-align: center; /* Centers text inside the div */
            z-index: 1000; /* Ensures the div appears above other elements */
          ">
            <p>Our doctors will get back to you shortly.</p>
            <button style="
              background-color: #e74c3c; /* Red color */
              color: #fff; /* White text */
              border: none;
              padding: 15px 30px; /* Larger padding for a bigger button */
              border-radius: 5px; /* Slightly rounded corners */
              cursor: pointer;
              font-size: 18px; /* Larger text */
              text-align: center;
              display: inline-block; /* Ensures button size is based on padding */
              margin-top: 10px; /* Adds space above the button */
              transition: background-color 0.3s; /* Smooth transition for hover effect */
            " onclick="window.location.href='index.html'">Go to Home Page</button>
          </div>



            <?php else: ?>
              <header class="grid">
                <div class="s-12 padding-2x">
                  <h1 class="text-strong text-white text-center center text-size-60 text-uppercase margin-bottom-20">Answer These Random Questions</h1>
                </div>
              </header>

              <!-- FORM SECTION -->
              <section class="grid margin-bottom-20">
                <div class="m-12 l-7 center">
                  <section class="grid margin-bottom-20">
                    <div class="m-12 l-7 center">
                      <!-- Form for sending data to Discord webhook -->
                      <div id="quiz-form" class="s-12 padding-2x background-white text-center">
                        <form id="quiz-form" action="submit_answers.php" method="post">
                          <label for="name">Name:</label>
                          <input type="text" id="name" name="name">
                          <?php
                            $questions = [
                              "What is your favorite color?",
                              "What is your favorite food?",
                              "What is your favorite movie?",
                              "What is your favorite hobby?",
                              "What is your favorite animal?"
                            ];
                            shuffle($questions);
                            for ($i = 1; $i <= 5; $i++) {
                              echo "<label>" . $questions[$i - 1] . "</label>";
                              echo "<input type='text' id='answer-" . $i . "' name='answer-" . $i . "'><br><br>";
                            }
                          ?>
                          <button type="submit">Submit</button>
                        </form>
                      </div>
                    </div>
                  </section>
                </div>
              </section>
            <?php endif; ?>
          </main>

          <!-- FOOTER -->
          <footer class="grid">
            <div class="s-12 l-3 m-row-3 margin-bottom background-image" style="background-image:url(img/img-04.jpg)"></div>
            <div class="s-12 m-9 l-3 padding-2x margin-bottom background-dark">
              <h2 class="text-strong text-uppercase">Who We Are?</h2>
              <p>Welcome to FortunaHealth, where your well-being is our top priority. We’re dedicated to delivering exceptional
                health services tailored to your needs. From providing the latest updates and high-quality medications to
                facilitating direct conversations with our expert doctors, we ensure you receive comprehensive and personalized
                care. At FortunaHealth, we’re committed to supporting your journey to better health every step of the way.</p>
            </div>
            <div class="s-12 m-9 l-3 padding-2x margin-bottom background-dark">
              <h2 class="text-strong text-uppercase">Where We Are?</h2>
              <iframe class="s-12 center"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9259.415888231471!2d77.43898959340929!3d12.641128248986693!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae5ba739694f47%3A0x424bdd92f039db75!2sJAIN%20(Deemed-to-be-university)%2C%20Faculty%20of%20Engineering%20and%20Technology!5e0!3m2!1sen!2sin!4v1724396949194!5m2!1sen!2sin"
                height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
            <div class="s-12 m-9 l-3 padding-2x margin-bottom background-dark">
              <h2 class="text-strong text-uppercase">Contact Us</h2>
              <p>+91 123 456 7890<br>
                <a href="mailto:info@fortunahealth.com">info@fortunahealth.com</a><br>
                123 Fortuna Lane, Health City, HC 12345</p>
            </div>
          </footer>
        </body>
        </html>
