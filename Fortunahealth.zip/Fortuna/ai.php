<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta charset="utf-8">
  <title>Fortuna Health</title>
  <!-- Link to Fortuna Health CSS files -->
  <link rel="stylesheet" href="css/components.css">
  <link rel="stylesheet" href="css/icons.css">
  <link rel="stylesheet" href="css/responsee.css">
  <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
  <link rel="stylesheet" href="owl-carousel/owl.theme.css">
  <!-- Custom Style -->
  <link rel="stylesheet" href="css/template-style.css">
  <link href="https://fonts.googleapis.com/css?family=Barlow:100,300,400,700,800&amp;subset=latin-ext" rel="stylesheet">
  <style>
    body {
      background-color: #2c3e50; /* Match this color with the footer background-dark color */
      color: black;
      font-family: 'Barlow', sans-serif;
    }
    #chat-container {
      max-width: 600px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    #chat-box {
      width: 100%;
      height: 150px;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
      font-size: 16px;
    }
    #chat-response {
      margin-top: 10px;
      padding: 10px;
      background-color: #f9f9f9;
      border: 1px solid #ccc;
      border-radius: 4px;
      min-height: 50px;
    }
    #chat-submit {
      background-color: #e74c3c;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      margin-top: 10px;
    }
    #chat-submit:hover {
      background-color: #c0392b;
    }
  </style>
</head>
<body>
  <!-- HEADER -->
  <header class="grid">
    <!-- Top Navigation -->
    <nav class="s-12 grid background-none background-primary-hightlight">
      <!-- logo -->
      <a href="index.html">
        <img src="img/Fortuna.png" width="100" height="100">
      </a>
      <div class="top-nav s-12 l-9">
        <ul class="top-ul right chevron">
          <li><a href="index.html">Home</a></li>
          <li><a href="about-us.html">About Us</a></li>
          <li><a href="contact.html">Contact</a></li>
        </ul>
      </div>
    </nav>
  </header>

  <!-- MAIN -->
  <main role="main">
    <header class="grid">
      <div class="s-12 padding-2x">
        <h1 class="text-strong text-white text-center center text-size-60 text-uppercase margin-bottom-20">Ask Our AI Assistant about any Problems</h1>
      </div>
    </header>
    <iframe
      class="center"
      src="https://www.chatbase.co/chatbot-iframe/NT3tnYEIBrbI5-qlESo2q"
      width="50%"
      style="height: 100%; min-height: 700px"
      frameborder="0"
    ></iframe>
  </main>

  <!-- FOOTER -->
  <footer class="grid">
    <div class="s-12 l-3 m-row-3 margin-bottom background-image" style="background-image:url(img/who\ we\ are.png)"></div>
    <div class="s-12 m-9 l-3 padding-2x margin-bottom background-dark">
      <h2 class="text-strong text-uppercase">Who We Are?</h2>
      <p>Welcome to FortunaHealth, where your well-being is our top priority. We’re dedicated to delivering exceptional
        health services tailored to your needs. From providing the latest updates and high-quality medications to
        facilitating direct conversations with our expert doctors, we ensure you receive comprehensive and personalized
        care. At FortunaHealth, we’re committed to supporting your journey to better health every step of the way.</p>
    </div>
    <div class="s-12 m-9 l-3 padding-2x margin-bottom background-dark">
      <h2 class="text-strong text-uppercase">Where We Are?</h2>
      <iframe class="s-12 center"
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9259.415888231471!2d77.43898959340929!3d12.641128248986693!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae5ba739694f47%3A0x424bdd92f039db75!2sJAIN%20(Deemed-to-be-university)%2C%20Faculty%20of%20Engineering%20and%20Technology!5e0!3m2!1sen!2sin!4v1724396949194!5m2!1sen!2sin"
        height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
    <div class="s-12 m-9 l-3 padding-2x margin-bottom background-dark">
      <h2 class="text-strong text-uppercase">Contact Us</h2>
      <p>+91 89710 29764 - Krishna</p>
      <p>+91 99456 88105 - Kshitij</p>
      <p>+91 78923 27796 - Kaushik</p>
      <p>+91 99428 67200 - Kailosh</p>
      <p><b class="text-primary margin-right-10">Company mail</b> <a class="text-primary-hover" href="mailto:contact@sampledomain.com">FortunaHealth@gmail.com</a></p>
    </div>
    <div class="s-12 text-center margin-bottom">
      <p class="text-size-12">Copyright - K Gang</p>
    </div>
  </footer>
</body>
</html>
